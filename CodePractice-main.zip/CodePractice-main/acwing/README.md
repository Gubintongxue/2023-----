# 常用代码模板1-基础算法 y总的课程的[模板](https://www.acwing.com/blog/content/277/)
# 常用代码模板2-数据结构 y总的课程的[模板](https://www.acwing.com/blog/content/404/)
# 常用代码模板3-搜索与图论 y总的课程的[模板](https://www.acwing.com/blog/content/405/)
# 常用代码模板4-数学知识 y总的课程的[模板](https://www.acwing.com/blog/content/406/)